import 'package:flutter/material.dart';

class AssetManager
{
  static String imgPath = "assets/images" ;

  static String laptop="assets/images/L1.png";
  static String phone="assets/images/S2.png";
  static String watch="assets/images/S3.png";
  static String tv="assets/images/T3.png";
  static String fridge="assets/images/F1.png";
  static String speaker="assets/images/S4.png";
  static String  ac="assets/images/A3.png";
  static String  cam="assets/images/C2.png";

}