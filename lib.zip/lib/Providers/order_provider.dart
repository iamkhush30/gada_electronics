import 'dart:ffi';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gadaelectronics_user/Providers/Products_Providers.dart';
import 'package:gadaelectronics_user/Providers/cart_provider.dart';
import 'package:gadaelectronics_user/Root_Screen.dart';
import 'package:gadaelectronics_user/Screens/Inner_Screen/Order/Order_Screen.dart';
import 'package:gadaelectronics_user/Services/MyApp_Function.dart';
import 'package:gadaelectronics_user/models/cart_model.dart';
import 'package:gadaelectronics_user/models/order_model.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

class OrderProvider with ChangeNotifier {

  final Map<String, OrderModel> _OrderList = {};

  Map<String, OrderModel> get getOrderList {
    return _OrderList;
  }

  final Map<String, CartModel> _ProductList = {};

  Map<String, CartModel> get getProductList {
    return _ProductList;
  }

  final Map<String, List<CartModel>> _userproducts = {};

  Map<String, List<CartModel>> get getUserProductList {
    return _userproducts;
  }

  final userDB = FirebaseFirestore.instance.collection("users");
  final _auth = FirebaseAuth.instance;

  Future<void> placeOrder({required String addressId,required BuildContext context})async{
    final User? user = _auth.currentUser;
    final cartProvider = Provider.of<CartProvider>(context,listen: false);
    final productProvider = Provider.of<ProductProvider>(context,listen: false);

    if(user==null) {
      MyAppFunction.showErrororWarnig(
          context: context,
          subTitel: "Please Login first",
          fct: (){}
      );
      return;
    }
    final uid = user.uid;
    final orderId = Uuid().v4();


    try{
      final List<Map<String, dynamic>> productsList = _ProductList.values.map((cartModel) => cartModel.toMap()).toList();
      await userDB.doc(uid).update({
        'userOrder': FieldValue.arrayUnion([{
          'orderId': orderId,
          'userId': uid,
          'orderTime': Timestamp.now(),
          'products': productsList,
          'addressId': addressId,
          'totalProductQut': cartProvider.getQty(),
          'totalAmount': cartProvider.getTotal(productProvider: productProvider),
        }])
      });
      await fetchOrder();
      Fluttertoast.showToast(msg: "Product has been added");
      Navigator.pushNamed(context, RootScreen.routName);
    } catch(error){
      rethrow;
    }
  }

  Future<void> fetchOrder ()async{
    final User? user = _auth.currentUser;

    if(user==null) {
      _OrderList.clear();
      return;
    }

    try{
      final userDoc = await userDB.doc(user.uid).get();
      final data = userDoc.data();

      if(data==null || !data.containsKey('userOrder')){
        return;
      }

      final userOrders = userDoc.get('userOrder');

      for (final orderData in userOrders) {
        final orderId = orderData['orderId'];

        if (orderId != null) {
          final order = OrderModel(
            orderId: orderId,
            userId: orderData['userId'],
            orderTime: orderData['orderTime'],
            products: orderData['products'],
            addressId: orderData['addressId'],
            totalProductQut: orderData['totalProductQut'],
            totalAmount: (orderData['totalAmount'] as num).toDouble(),
          );

          _OrderList.putIfAbsent(orderId, () => order);

          for (final productMap in order.products) {
            final productId = productMap['productId'];
            final product = CartModel(
              cartId: productMap['cartId'],
              orderId: orderId,
              productId: productId,
              quantity: productMap['quantity'],
            );

            _ProductList.putIfAbsent(productId, () => product);
          }
        }
      }

    } catch(error){
      rethrow;
    }
    notifyListeners();
  }

  Future<void> getUserProducts(String orderId,) async {
    try {
      final productsForOrder = _ProductList.values.where((product) => product.orderId == orderId).toList();

      if (!_userproducts.containsKey(orderId)) {
        _userproducts[orderId] = List<CartModel>.from(productsForOrder);
      }
      print("---------------------------------${_userproducts[orderId].toString()}");
    } catch (error) {
      rethrow;
    }
  }

  Future<void> removeUserProduct() async {
    try {
      _userproducts.clear();
    } catch (error) {
      rethrow;
    }
  }
}