import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:uuid/uuid.dart';

class ProductModel with ChangeNotifier {
  final String productId,
      productTitle,
      productPrice,
      productCategory,
      productDescription,
      productImage,
      productQuantity;
  Timestamp? createdAt;
  ProductModel({
    required this.productId,
    required this.productTitle,
    required this.productPrice,
    required this.productCategory,
    required this.productDescription,
    required this.productImage,
    required this.productQuantity,
    this.createdAt,
  });

  factory ProductModel.fromFirestore(DocumentSnapshot doc){
    Map data = doc.data() as Map<String,dynamic>;

    return ProductModel(
        productId: data["productId"],
        productTitle: data["productTitle"],
        productPrice: data["productPrice"],
        productCategory: data["productCategory"],
        productDescription: data["productDescription"],
        productImage: data["productImage"],
        productQuantity: data["productQuantity"],
        createdAt: data["createdAt"]
    );
  }

  static List<ProductModel> products = [
    // Phones
    ProductModel(
      //101
      productId: const Uuid().v4(),
      productTitle: "Boat Stone 135 Portable Wireless Speaker with 5W RMS Immersive Sound,IPX4 Water Resistance,True Wireless Feature, Up to 11H Total Playtime, Multi-Connectivity Modes With Type C Charging(Soldier Green)",
      productPrice: "₹999.00",
      productCategory: "Speaker",
      productDescription: "• Power - Get ready to be enthralled by the 5W RMS sound on Stone 135 portable wireless speakers."
          "\n\n• True Wireless- It supports TWS functionality meaning you can connect two Stone 135s together and simultaneously play music on both of them for twice the impact."
          "\n\n• Playback- The speaker offers up to a total of 11 hours of playtime per single charge at 80% volume level."
          "\n\n• IP Rating- With a lightweight speaker that offers an IPX4 marked resistance against water and splashes, you can enjoy your playlists across terrains in a carefree and hassle-free way."
          "\n\n• Connectivity- You can enjoy your playlists via multiple connectivity modes namely Bluetooth, FM Mode and TF Card."
          "\n\n• Controls- You can control playback, adjust volume levels, activate default voice assistant, etc., with ease courtesy easy to access controls"
          "\n\n• Calling and Mic- The speaker also supports hands free calling feature as it has a built-in mic as well."
          "\n\n • Note- Kindly remove the sticky translucent film from the bottom of the speaker before you start using it.",
      productImage: "assets/product/speaker/S1.png",
      productQuantity: "10",
    ),
    ProductModel(
      //102
      productId: const Uuid().v4(),
      productTitle:
      "boAt Stone 170 with 5W Speaker Bluetooth V4.2 and a SD Card Slot, with a Playback time of 6 Hours, IPX 6 Water Resistant Design (Black)",
      productPrice: "₹1,299",
      productCategory: "Speaker",
      productDescription: "• Stone 170 comes with a powerful 1800mAh Lithium Battery which provides a battery back up of upto 6 hours."
          "\n\n• Set up your wireless sound on your chosen device and let the music play its way through the day, its style done right with the boAt Stone 170"
          "\n\n• It is IPX6 rated which offers protection against sweat and water."
          "\n\n• With a multifunction button and volume buttons that allow for easy interface, ensuring that nothing stands between you and your favourite music"
          "\n\n• Fitted in a compact rugged structure made to survive the elements and add a little bit of colour to your décor, carry your style with Stone 170"
          "\n\n• For audiophiles that love catching every snare and snap with that deep booming bass that allows for a memorable listening experience on a power output of 5W"
          "\n\n• Connect two Stone 170’s and turn the scene right around with double the volume at the same clarity level, get the party started anywhere, anytime with the boAt Stone 170"
          "\n\n• 1 year warranty from the date of purchase",
      productImage: "assets/product/speaker/S2.png",
      productQuantity: "15",
    ),
    ProductModel(
      //103
      productId: const Uuid().v4(),
      productTitle: "boAt Stone 352 Bluetooth Speaker with 10W RMS Stereo Sound, IPX7 Water Resistance, TWS Feature, Up to 12H Total Playtime, Multi-Compatibility Modes and Type-C Charging(Raging Black)",
      productPrice: "₹1,599",
      productCategory: "Speaker",
      productDescription: "• Power- Get ready to be enthralled by the 10W RMS stereo sound on Stone 352 portable wireless speakers."
          "\n\n• IP Rating- With a speaker that offers an IPX7 marked resistance against water and splashes, you can enjoy your playlists across terrains in a carefree way. Charging Time About 1.5-2 hours"
          "\n\n• Playback- The speaker offers up to a total of 12 hours of playtime per single charge at 60% volume level. Bluetooth Range - 10m"
          "\n\n• True Wireless- It supports TWS functionality, meaning you can connect two Stone 352s together and simultaneously play music on both of them for twice the impact."
          "\n\n• Modes- You can enjoy your playlists via multiple connectivity modes namely Bluetooth, AUX and TF Card."
          "\n\n• Controls- You can control playback and adjust volume levels with ease courtesy easy to access controls.",
      productImage: "assets/product/speaker/S3.png",
      productQuantity: "20",
    ),
    ProductModel(
      //104
      productId: const Uuid().v4(),
      productTitle:
      "boAt Stone 1200 14W Bluetooth Speaker with Upto 9 Hours Battery, RGB LEDs, IPX7 and TWS Feature(Blue)",
      productPrice: "₹3,999",
      productCategory: "Speaker",
      productDescription: "• It delivers a powerful 14W stereo sound for a complete immersive experience."
          "\n\n• Stone 1200 provides a battery time of upto 9 hours without its RGB LEDs and upto 7 hours with it(@60% volume) with a charging time of 4 hours. Driver Size: 76mm * 2 Drivers"
          "\n\n• Carry your splash-proof speakers to anywhere with IPX7 splash &nwater shield leaving behind the tension of water running over"
          "\n\n• Add a second speaker with our TWS technology and enjoy sound, twice as powerful"
          "\n\n• Its 360-degree ergonomic design makes it ideal to be carried around anywhere you go. It also comes with a carry strap making it very convenient for you to carry it around."
          "\n\n• With its Type-c interface there's no fussing over up or down orientation while charging."
          "\n\n• Stone 1200 comes with multiple connectivity modes: Bluetooth v5.0, AUX, USB, FM",
      productImage: "assets/product/speaker/S4.png",
      productQuantity: "2363",
    ),
    ProductModel(
      //105
      productId: const Uuid().v4(),
      productTitle:
      "Infinity - JBL Clubz Mini, Wireless Ultra Portable Mini Speaker with Mic, Deep Bass, Dual Equalizer, Bluetooth 5.0 with Voice Assistant Support for Mobiles (Black)",
      productPrice: "₹898",
      productCategory: "Speaker",
      productDescription: "• 5 hours Music Playtime Under Optimum Audio Settings\n"
          "• Pocket Size Portable Bluetooth Speakers\n"
          "• Dual Equalizer Modes for Normal & Deep Bass Output\n"
          "• Wireless Bluetooth Streaming\n"
          "• Speakerphone and Voice Assistant Integration",
      productImage: "assets/product/speaker/S5.png",
      productQuantity: "3625",
    ),
    ProductModel(
      //106
      productId: const Uuid().v4(),
      productTitle:
      "JBL Partybox 310 | Portable Bluetooth Party Speaker | 240W Monstrous Pro Sound | Dynamic Light Show | Backlit Panel | Telescopic Handle & Wheels | Guitar & Mic Support PartyBox App (Black)",
      productPrice: "₹38,999",
      productCategory: "Speaker",
      productDescription:
          "• Replacement, Installation & On-Site Repair within 24 hours( in Select cities). T&C Apply\n\n"
          "• POWERFUL JBL ORIGINAL PRO SOUND: Around the block or across the beach, make your party heard with 240 watts of JBL Signature Sound and extra deep bass. Sing, rap, strum and watch the dance floor come alive.\n\n"
          "• PARTY LIGHTS: Mesmerize your friends with a cool, dynamic lightshow that syncs to the beat. With subtle pulsing and powerful strobing effects, there's a setting for every party.\n\n"
          "• 18 HOURS OF PLAYTIME AND PORTABLE DESIGN: Built-in rechargeable battery for up to 18 hours of playtime. With a telescopic handle and built-in smooth-glide wheels, it's easy to take the party anywhere.\n\n"
          "• IPX4 SPLASHPROOF: Beach bashes, poolside parties or dancing in the rain. IPX4 splashproof protection keeps your JBL PartyBox310 safe when your party gets a little wet\n\n"
          "• Sound effect generator: Have even more fun with built-in sound effects or just blast the airhorn to get the dance floor jumping. Add some creativity to the mix via dual mic and guitar inputs. The sound control panel has backlighting that activates in the dark. You'll be able to keep the party going, with no need for a flashlight.\n\n"
          "• What's in the box: 1 x JBL Partybox 310 Speaker, 1 x AC Power Code (AC Plug varies by Region), 1 x Quick-Start Guide, 1 x Warranty Card, 1 x Safety Sheet",
      productImage: "assets/product/speaker/S6.png",
      productQuantity: "3636",
    ),

    ProductModel(
      //107
      productId: const Uuid().v4(),
      productTitle: "Marshall Acton III 60 W Bluetooth Powered Home Speaker, Black",
      productPrice: "₹31,999",
      productCategory: "Speaker",
      productDescription:
          "• E-ENGINEERED WIDER STEREO SOUNDSTAGE: Generation III has tweeters angled outwards and updated waveguides to deliver a consistently solid sound that is so wide it chases you around the room. The all-new Placement Compensation feature corrects for any nearby reflective surfaces that may affect the sound and built-in Dynamic Loudness adjusts the tonal balance, ensuring your music sounds brilliant at every volume\n\n"
          "• PAIR, PLAY AND TURN IT UP: You’ll find everything you need right there on the unit, including the Bluetooth pairing button, power switch, bass and treble controls and the control knob so you can easily control your music without ever picking up your device.\n\n"
          "• NEXT-GENERTAION BLUETOOTH: Ready for the future of Bluetooth technology and has been built to deliver next-generation Bluetooth features the moment they are available\n\n"
          "• A MORE SUSTAINABLE APPROACH: Music at heart and the environment in mind. This new generation takes a more sustainable approach with a PVC-free build that comprises 70% recycled plastic and only vegan materials.\n\n"
          "• CONNECT AND CONTROL: Bluetooth 5.2 and the 3.5 mm input, connecting to your speaker and listening to your music has never been so effortless.",
      productImage: "assets/product/speaker/S7.png",
      productQuantity: "525",
    ),
    ProductModel(
      //108
      productId: const Uuid().v4(),
      productTitle: "Sony SRS-XB100 Wireless Bluetooth Portable Lightweight Super-Compact Travel Speaker, Extra-Durable IP67 Waterproof & Dustproof, 16 Hrs Batt, Versatile Strap, Extra Bass & Hands-Free Calling-Blue",
      productPrice: "₹4,490",
      productCategory: "Speaker",
      productDescription:
          "• Take it wherever you want: The durable exterior & strap make this speaker ready for just go any where. Hang it at your backpack, on your wrist, or even from a tree when you’re out in the sun, & the downwards-facing speaker will project the sound.\n\n"
          "• USB Type-C port : Charge the XB100 with the USB Type-C port.\n\n"
          "• Long live your music : The XB100 has upto 16 hours of battery life, so that you & your friends can listen to music all day & into the night. The remaining battery percentage shows clearly on your smartphone when the XB100 is connected.\n\n"
          "• Small speaker that packs a powerful, clear sound : Music is the soundtrack to our lives, & we want you to be able to enjoy your tunes wherever you are. So we’ve packed powerful, clear sound into a portable body.\n\n"
          "• Portable and durable for life on the go : You want to take your music wherever you go, with the XB100 you can do just that. The compact body is durable & light-weight, Long Life Battery & the multiway strap makes it perfect for carrying\n\n"
          "• Sustainability in mind : The XB100 body & strap are partially made from recycled plastic materials to help reduce the environmental impact. We’re also proud to say that our packaging uses no plastic material.\n\n"
          "• Get more from your speaker : We want your speaker to fit into your lifestyle. As well as listening to music, you can use it to take and make calls. Plus, you can pair a second speaker via Bluetooth, for stereo sound.",
      productImage: "assets/product/speaker/S8.png",
      productQuantity: "2526",
    ),

    //--------------------------------------Mobiles--------------------------------------

    ProductModel(
      //201
      productId: const Uuid().v4(),
      productTitle: "SAMSUNG Galaxy S22 5G (Green, 128 GB)  (8 GB RAM)",
      productPrice: "₹62,999",
      productCategory: "Mobiles",
      productDescription: "• Pro-grade Camera that lets you make your nights epic with Nightography: It’s our brightest innovation yet. The sensor pulls in more light, the Super Clear Glass dials down lens flare, and fast-acting AI delivers near-instant intelligent processing."
          "\n\n• VisionBooster outshines the sun: Stunning 120Hz Dynamic AMOLED 2X display is crafted specifically for high outdoor visibility, keeping the view clear in bright daylight."
          "\n\n• 4nm processor, our fastest chip yet: Our fastest, most powerful chip ever. That means, a faster CPU and GPU compared to Galaxy S21 Ultra. It’s an epic leap for smartphone technology."
          "\n\n• Sleek design in a range of colors lets you express yourself how you like. The slim bezels flow into a symmetrical polished frame for an expansive, balanced display. Corning Gorilla Glass Victus+ on the screen and back panels.",
      productImage: "assets/product/moblies/M1.png",
      productQuantity: "10",
    ),
    ProductModel(
      //202
      productId: const Uuid().v4(),
      productTitle: "vivo V27 5G (Magic Blue, 256 GB)  (12 GB RAM)",
      productPrice: "₹35,999",
      productCategory: "Mobiles",
      productDescription: "• The Vivo V27 Pro 5G's 3D Curved Screen boasts a large size of 17.22 cm (6.78), a 120 Hz refresh rate, and up to 1.07 billion colours. This way, you can enjoy a full-view immersive experience that gives you the impression that you are carrying a movie theatre in your pocket."
          "\n\n• Experience the exciting ways your phone responds to light. The Colour Changing Glass appears to be touched by charm as it shifts from a light shade of blue to a darker one as light intensity increases."
          "\n\n• In addition to having a 50 MP primary camera with excellent resolution, this smartphone also has a Sony IMX766V ultra-sensing sensor. Furthermore, Optical Image Stabilization (OIS) lengthens exposure and boosts light intake. That's enough light to create vibrant, dazzling nighttime images."
          "\n\n• The Wedding Style Portrait is a combination of warm, pastel tones and a mixture of soft contrast gold/pink tones, reflecting the colour palette of grand Indian weddings. It has been created with inspiration from the colours and contrast of Indian weddings."
          "\n\n• Your phone performs efficiently thanks to MediaTek Dimensity 8200, which also facilitates smooth multitasking, allowing you to maintain high levels of productivity."
          "\n\n• This phone's amazing Extended RAM 3.0 technology boosts your phone's RAM by up to 8 GB. The V27 Pro can therefore accommodate up to 36 programmes running in the background concurrently with 12 GB of RAM."
          "\n\n• Your phone can charge up to 50% in just 18 minutes when the screen is off, 70% in 27 minutes, and 100% within one hour owing to Vivo's 66 W Dual-Engine Fast Charging technology.",
      productImage: "assets/product/moblies/M2.png",
      productQuantity: "15",
    ),
    ProductModel(
      //203
      productId: const Uuid().v4(),
      productTitle: "vivo X100 Pro (Asteroid Black, 512 GB)  (16 GB RAM)",
      productPrice: "₹89,999",
      productCategory: "Mobiles",
      productDescription: "• The newly upgraded vivo origin imaging engine, X100 series has been optimized for photographing the sun in various environments. Feel a sense of wonder by capturing the magical sun in all its glory. Photos have accurate colour tones of the sun without glare, noise and the telephoto camera enables zoom with good clarity."
          "\n\n• Click portraits at different focal lengths which are equal to different zoom levels: 24 mm(1x), 35 mm (1.5x), 50 mm (2.2x), 85 mm (3.7x), and 100 mm (4.3x). These different focal lengths are combined with the ZEISS Style Portraits. Along with recommended styles and colour options, it can meet users' diverse needs for everyday life and travel photography."
          "\n\n• This smartphone is powered by MediaTek Dimensity 9300 with a 2.21 Mn AnTuTu score. Flagship All Big Core CPU design CPU with 4 super cores and 4 large cores, reaching peak performance. Best Arm Immortalis G720 GPU: peak performance increased by 35% and energy efficiency increased by 30%."
          "\n\n• X100 series adopts the V Frame Rate Management system. This ensures smart switching of the screen's frame rate according to user needs. It Intelligently adjusts the screen refresh rate based on the finger slide speed on the screen. Experience a smooth viewing experience, with upgraded Eye Protection and power consumption control."
          "\n\n• A truly Durable choice with IP68 Water and Dust resistance. Tackle more of life’s little mishaps with ease. Use it freely without worrying about splashes or dust ingress.",
      productImage: "assets/product/moblies/M3.png",
      productQuantity: "20",
    ),
    ProductModel(
      //204
      productId: const Uuid().v4(),
      productTitle: "Apple iPhone 15 Pro Max (Blue Titanium, 256 GB)",
      productPrice: "₹1,56,900",
      productCategory: "Mobiles",
      productDescription: "• FORGED IN TITANIUM — iPhone 15 Pro Max has a strong and light aerospace-grade titanium design with a textured matte-glass back. It also features a Ceramic Shield front that’s tougher than any smartphone glass. And it’s splash, water, and dust resistant."
          "\n\n• ADVANCED DISPLAY — The 6.7” Super Retina XDR display with ProMotion ramps up refresh rates to 120Hz when you need exceptional graphics performance. Dynamic Island bubbles up alerts and Live Notifications. Plus, with Always-On display, your Lock Screen stays glanceable, so you don’t have to tap it to stay in the know."
          "\n\n• GAME-CHANGING A17 PRO CHIP — A Pro-class GPU makes mobile games feel so immersive, with rich environments and realistic characters. A17 Pro is also incredibly efficient and helps to deliver amazing all-day battery life."
          "\n\n• POWERFUL PRO CAMERA SYSTEM — Get incredible framing flexibility with 7 pro lenses. Capture super high-resolution photos with more color and detail using the 48MP Main camera. And take sharper close-ups from farther away with the 5x Telephoto camera on iPhone 15 Pro Max."
          "\n\n• CUSTOMIZABLE ACTION BUTTON — Action button is a fast track to your favorite feature. Just set the one you want, like Silent mode, Camera, Voice Memo, Shortcut, and more. Then press and hold to launch the action.",
      productImage: "assets/product/moblies/M4.png",
      productQuantity: "2363",
    ),
    ProductModel(
      //205
      productId: const Uuid().v4(),
      productTitle: "OnePlus 11R 5G (Sonic Black, 16GB RAM, 256GB Storage)",
      productPrice: "₹44,999",
      productCategory: "Mobiles",
      productDescription: "• Camera: Sensor: 50MP Main Camera with Sony IMX890 (OIS supported), 8MP Ultrawide Camera (FOV: 120 degree) and Macro Lens; 16MP Front (Selfie) Camera with EIS support."
          "\n\n• Camera Modes: Nightscape, Ultra HDR, Smart Scene Recognition, Portrait Mode, Pro Mode, Panorama, Tilt-Shift mode, Long Exposure, Dual-View Video, Retouch, Movie Mode, Raw file, Filters,Super Stable, Video Nightscape, Video HDR, Video Portrait, Focus Tracking, Timelapse, Macro mode."
          "\n\n• Display: 6.7 Inches; 120 Hz Super Fluid AMOLED; Resolution: 2772 X 1240 pixels ,450 ppi, 20.1:9, 10-bit Color Depth, HDR10+."
          "\n\n• Operating System: OxygenOS based on Android 13."
          "\n\n• Processor: Snapdragon 8+ Gen 1 Mobile Platform.",
      productImage: "assets/product/moblies/M5.png",
      productQuantity: "3625",
    ),
    ProductModel(
      //206
      productId: const Uuid().v4(),
      productTitle: "OPPO Reno10 Pro+ 5G (Glossy Purple, 256 GB)  (12 GB RAM)",
      productPrice: "₹54,999",
      productCategory: "Mobiles",
      productDescription: "• This phone boasts a 50 MP OIS main camera that takes ultra-clear pictures. The camera on this phone is 112 degrees ultra-wide angle and has an AutoFocus smart selfie feature that lets you capture beautiful pictures of yourself and groups. You can also record 4K ultra-clear video anytime you want."
          "\n\n• Make your moments your memories by clicking unbelievable portraits with the fabulous camera built on this phone. Click beautiful pictures of your intimate moments and collect memories with this Sony IMX709 flagship sensor. This flagship camera takes professional photos in portrait focal lengths and clear images every time you take a picture. Take clear pictures of your natural beauty and experience the joy of photography like never before."
          "\n\n• Take stunning and ultra-clear pictures on this carefully designed camera where you don’t have to compromise on the quality of the photos you take."
          "\n\n• With this specially built portrait special mode camera by industry experts, you can take spellbinding pictures that are worth cherishing for years together."
          "\n\n• Look stylish with this 3D curved design smartphone and attract all gaze with its sheer beauty, smooth contours that just fits right on your palm."
          "\n\n• The attractive look of the camera is sure to allure everyone and the laser-centric camera further enhances the beauty of this phone."
          "\n\n• Designed to be featherlight and sleek, this phone unleashes pro-level photography. You can also slide this smartphone into your backpack or pocket and it feels so light that you won't even know it is there.",
      productImage: "assets/product/moblies/M6.png",
      productQuantity: "3636",
    ),
    ProductModel(
      //207
      productId: const Uuid().v4(),
      productTitle: "realme 11 Pro 5G (Sunrise Beige, 128 GB)  (8 GB RAM)",
      productPrice: "₹24,999",
      productCategory: "Mobiles",
      productDescription: "• [Display] :- Curved Vision Display, The realme Pro 5G smartphone has a 120 Hz curved vision display that ensures immersive display. It comes with an array of features like 2160 Hz PWM dimming, TUV Rheinland certified eye protection features, 1260 Hz Turbocharged Touch Sampling, and 16x HyperPrecise Touch for a smooth and hassle-free usage. The 2.33 Chin, 61-degree Precision Curvature, and Doubly reinforced Glass gives an aesthetic look and perfectly fits in your hands."
          "\n\n• [Processor] :- Powerful Processor, The Dimensity 7050 5G chipset of this smartphone delivers fast and smooth performance. The realme Pro 5G smartphone has 5G compatibility along with TUV SUD rating for 48-month system fluency, Dash Memory Engine, 6 nm technology process, and an AnTuTu score above 550,000 which makes it a feature-packed smartphone."
          "\n\n• [Fast Charging Technology] :- Fast Charging, Equipped with a 67 W SUPERVOOC charge, this smartphone can be charged from 0-50% in less than 18 minutes. It has more than 38 safety protections and Intelligent Five-core Chip Protection which ensures fast charging and safety."
          "\n\n• [Massive Battery] :- 5000 mAh Battery, This smartphone features a massive battery of 5000 mAh which ensures that you have enough power to get on with the day. You can enjoy up to 29.09 hours of call time, 404.88 hours of standby time, 23.36 hours of music time, 18.86 hours of video time, and 8.29 hours of game time."
          "\n\n• [Amazing Design] :- Aesthetic Design, This smartphone is designed by the former Gucci prints designer, Matteo Menotto featuring a Premium Lychee Vegan Leather, 3D Couture-level Seam, and 3D Woven Texture that makes it classy and stylish."
          "\n\n• [Massive Storage] :- Massive Storage, This smartphone comes with a 256 GB of storage space which allows you to store all kinds of data seamlessly.",
      productImage: "assets/product/moblies/M7.png",
      productQuantity: "525",
    ),
    ProductModel(
      //208
      productId: const Uuid().v4(),
      productTitle: "REDMI Note 12 Pro 5G (Onyx Black, 128 GB)  (6 GB RAM)",
      productPrice: "₹21,999",
      productCategory: "Mobiles",
      productDescription: "• Redmi Note 12 Pro 5G packs an uber stylish design in an ultra slim body, at just 7.98 mm of thickness. It comes in 3 stunning colours: Glacier Blue, Onyx Black and Stardust Purple."
          "\n\n• Redmi Note 12 Pro 5G features the flagship 50 MP Sony IMX766 sensor. The sensor with 1 um pixel size captures a lot more light resulting in excellent low light shots."
          "\n\n• With Redmi Note 12 Pro 5G series, we are introducing OIS for the first time ever on a Redmi Note. OIS helps in negating the camera-shake resulting in stable, blur free images especially in low light conditions."
          "\n\n• The display on Redmi Note 12 Pro 5G is a 120 Hz Pro AMOLED display with adaptive sync. It's smooth, vibrant, and a delight to use. The 10-bit display lends the device more than 1 billion+ colors. It also comes with Dolby Vision & HDR10+ support for stunning visuals."
          "\n\n• Redmi Note 12 Pro 5G comes with Dual Stereo Speakers with Atmos support which lends the device the ultimate multimedia experience."
          "\n\n• Redmi Note 12 Pro 5G comes with 67W charging which gives you full day's charge in 15 minutes along with a massive 5000mAh battery.",
      productImage: "assets/product/moblies/M8.png",
      productQuantity: "2526",
    ),

    //--------------------------------------Laptop--------------------------------------

    ProductModel(
      //301
      productId: const Uuid().v4(),
      productTitle: "SAMSUNG Galaxy Book2 Pro Intel EVO Intel Core i5 12th Gen 1240P - (16 GB/512 GB SSD/Windows 11 Home) NP930XED-KB3IN Thin and Light Laptop  (13.3 Inch, Silver, 0.87 Kg, With MS Office)",
      productPrice: "₹67,990",
      productCategory: "Laptop",
      productDescription: "• Processor: 12th Generation Intel EVOTM Core i5-1240P processor (1.7 GHz up to 4.4 GHz 12 MB L3 Cache) | Memory: 16 GB LPDDR5 Memory (On BD 16 GB) | Storage: 512 GB NVMe SSD."
          "\n\n• Operating System: Windows 11 Home | Preinstalled Software: MS Office Home & Student 2021, Live Message, Live Wallpaper, McAfee Live Safe (Trial), Screen Recorder, Samsung Gallery, Samsung Flow, Samsung Notes, Samsung Recovery, Samsung Settings, Studio Plus, Samsung Update, Samsung Security, Quick Share, Galaxy Book Smart Switch."
          "\n\n• Display: 13.3 inch (33.7 cm), FHD AMOLED Display (1920 x 1080) | Touchscreen | Intel Iris Xe Graphics | Design: Aluminum body with 11.5mm thinness and 1.04kg."
          "\n\n• Ports: 1 Thunderbolt 4, 2 USB Type-C, MicroSD Multi-media Card Reader, 1 Headphone out/Mic-in Combo, | Without CD-drive | Battery= 63 Wh, 65 W USB Type-C Adapter."
          "\n\n• Camera: 1080p FHD, Intelligent Video Call Solution with Intel Collaboration | Microphone: 1 Headphone out/Mic-in Combo | Keyboard: Pro Keyboard (Backlit), S Pen In box | FingerPrint Reader, Ambient Light Sensor, Accelerometer Sensor, Gyro Sensor.",
      productImage: "assets/product/laptop/L1.png",
      productQuantity: "10",
    ),
    ProductModel(
      //302
      productId: const Uuid().v4(),
      productTitle: "SAMSUNG Galaxy Book3 Pro EVO AMOLED Intel Core i7 13th Gen 1360P - (16 GB/1 TB SSD/Windows 11 Home) NP960XFG-KC2IN Thin and Light Laptop  (16 Inch, Graphite, 1.56 Kg, With MS Office)",
      productPrice: "₹1,50,990",
      productCategory: "Laptop",
      productDescription: "• Processor: 13th Gen Intel Core i7-1360P processor up to 5.0 GHz 18 MB L3 Cache) | Memory: 16 GB LPDDR5 Memory | Storage: 1 TB NVMe SSD, additional slot- expandable upto 1TB | Intel Iris Xe Graphics."
          "\n\n• Operating System: Windows 11 Home | Pre-Installed Software: MS Office Home & Student 2021, Galaxy Ecosystem Apps."
          "\n\n• Display: 16' (40.62 cm), Dynamic AMOLED 2X, 3K WQXGA+ (2880 x 1800) resolution | 16:10 Aspect Ratio | 120Hz | 500nits HDR |Design: Aluminum body with 12.5mm thinness and 1.56kg."
          "\n\n• Ports: 2 Thunderbolt 4-USB Type-C, 1 USB Type-A, 1 HDMI, MicroSD Multi-media Card Reader, 1 Headphone out/Mic-in Combo, | Wi-Fi 6E | Without CD-drive |Battery: 76 Wh, Charger: 65 W USB Type-C Adapter."
          "\n\n• Camera: 1080p, Intelligent Video Call Solution with Intel Collab | Quad AKG Speakers, Dolby Atmos | Microphone: 1 Headphone out/Mic-in Combo | Keyboard: Keyboard (Backlit), | FingerPrint Reader."
          "\n\n• Galaxy Ecosystem: Samsung Pass, Second Screen, Multi Control, Quick BT Connection, Phone Link, Quick Share, Private Share, Galaxy Book Experience.",
      productImage: "assets/product/laptop/L2.png",
      productQuantity: "15",
    ),
    ProductModel(
      //303
      productId: const Uuid().v4(),
      productTitle: "HP Victus Gaming Laptop, AMD Ryzen 5 5600H, AMD Radeon RX 6500M Graphics, 15.6-inch (39.6 cm), FHD, IPS, 144Hz, 9 ms Response time, 16GB DDR4, 512GB SSD, Backlit KB (Win 11, Blue, 2.29 kg), fb0134AX",
      productPrice: "₹54,990",
      productCategory: "Laptop",
      productDescription: "• 【6-core AMD Ryzen 5 5600H】12 threads and 16MB L3 cache enable you to dominate virtual battles with AMD SmartShift that dynamically adjusts power allocation between CPU and GPU to boost performance."
          "\n\n• 【4 GB AMD Radeon RX 6500M graphics】Experience immersive, lifelike gameplay with stunning graphics and accelerate heavy workflows with high-speed data processing, video editing, and rendering."
          "\n\n• 【Upgraded memory and storage】Make room for all your games with 512GB PCIe Gen4 NVMe TLC M.2 SSD. Plus, get 16GB DDR4 RAM that lets you take on any opponent with improved system responsiveness."
          "\n\n• 【Popular games】Play all your favourite games like League of Legends, Valorant, Fortnite, Call of Duty: Warzone, Apex Legends, Overwatch 2, Fall Guys, and more."
          "\n\n• 【Micro-edge display】The 15.6-inch, FHD, 250-nit, 144Hz, anti-glare, and micro-edge display keeps you in the thick of action with a fast 9 ms response time, reduced image ghosting, and crisp visuals."
          "\n\n• 【Effortless connectivity for uninterrupted gaming sessions】Wi-Fi 6E (2x2) and Bluetooth 5.2, 1 x USB Type-C, 2 x USB Type-A, and 1 x HDMI 2.1 ports provide seamless, swift connections."
          "\n\n• 【Long battery life】Fast charge your device to 50% in 45 mins and indulge in long gaming marathons with a 3-cell, 52.5Wh battery.",
      productImage: "assets/product/laptop/L3.png",
      productQuantity: "20",
    ),
    ProductModel(
      //304
      productId: const Uuid().v4(),
      productTitle: "ASUS Vivobook 16X AMD Ryzen 7 Octa Core 5800HS - (16 GB/512 GB SSD/Windows 11 Home) M1603QA-MB712WS Notebook  (16 inch, Transparent Silver, 1.8 kg, With MS Office)",
      productPrice: "₹59,373",
      productCategory: "Laptop",
      productDescription: "• Processor: AMD Ryzen 7 5800HS Mobile Processor Laptop (8-core/16-thread, 20MB cache, up to 4.4 GHz max boost)."
          "\n\n• Memory: 16GB (8GB DDR4 on board + 8GB DDR4 SO-DIMM) DDR4 | Storage: 512GB M.2 NVMe PCIe 3.0 SSD."
          "\n\n• Display: 16.0-inch, FHD+ (1920 x 1200) 16:10 aspect ratio, 60Hz refresh rate, 45% NTSC color gamut, Anti-glare display."
          "\n\n• Graphics: Integrated AMD Radeon Graphics."
          "\n\n• Keyboard: Backlit Chiclet Keyboard with Num-key."
          "\n\n• Operating System: Windows 11 Home | Software: Office Home and Student 2021 included."
          "\n\n• Design: 1.99 cm Thin | Thin and Light Laptop | US MIL-STD 810H military-grade standard | 1.88 kg weight | 50WHrs, 3S1P, 3-cell Li-ion | Up to 6 hours battery life ;Note: Battery life depends on conditions of usage.",
      productImage: "assets/product/laptop/L4.png",
      productQuantity: "2363",
    ),
    ProductModel(
      //305
      productId: const Uuid().v4(),
      productTitle: "ASUS TUF Gaming F15 Intel Core i5 12th Gen 12500H - (16 GB/512 GB SSD/Windows 11 Home/4 GB Graphics/NVIDIA GeForce RTX 3050) FX507ZC4-HN116W Gaming Laptop  (15.6 Inch, Mecha Gray, 2.20 Kg)",
      productPrice: "₹85,900",
      productCategory: "Laptop",
      productDescription: "• Camera: Sensor: 50MP Main Camera with Sony IMX890 (OIS supported), 8MP Ultrawide Camera (FOV: 120 degree) and Macro Lens; 16MP Front (Selfie) Camera with EIS support."
          "\n\n• Camera Modes: Nightscape, Ultra HDR, Smart Scene Recognition, Portrait Mode, Pro Mode, Panorama, Tilt-Shift mode, Long Exposure, Dual-View Video, Retouch, Movie Mode, Raw file, Filters,Super Stable, Video Nightscape, Video HDR, Video Portrait, Focus Tracking, Timelapse, Macro mode."
          "\n\n• Display: 6.7 Inches; 120 Hz Super Fluid AMOLED; Resolution: 2772 X 1240 pixels ,450 ppi, 20.1:9, 10-bit Color Depth, HDR10+."
          "\n\n• Operating System: OxygenOS based on Android 13."
          "\n\n• Processor: Snapdragon 8+ Gen 1 Mobile Platform.",
      productImage: "assets/product/laptop/L5.png",
      productQuantity: "3625",
    ),
    ProductModel(
      //306
      productId: const Uuid().v4(),
      productTitle: "DELL G15 Intel Core i5 12th Gen 12500H - (8 GB/512 GB SSD/Windows 11 Home/4 GB Graphics/NVIDIA GeForce RTX 3050/120 Hz) G15-5520 Gaming Laptop  (15.6 Inch, Dark Shadow Grey, 2.57 kg, With MS Office)",
      productPrice: "₹70,890",
      productCategory: "Laptop",
      productDescription: "• Processor: 12th Generation Intel Core i5-12500H (up to 4.60 GHz, 20MB 10 Cores) // RAM & Storage: 8GB, 1x8GB, DDR5, 4800MHz & 512GB SSD."
          "\n\n• Software: Pre-Loaded Windows 11 Home with Lifetime Validity | MS Office Home and Student 2021 with lifetime validity| McAfee Multi Device Security 15-month subscription."
          "\n\n• Display: 15.6' FHD Narrow 120Hz 250 nits -- Graphics & Keyboard: NVIDIA GEFORCE RTX 3050 (6GB GDDR6) & Backlit Keyboard 4-Zone RGB."
          "\n\n• Warranty: 1 Year Onsite Premium Support, Battery:3-Cell Battery, 56WHr."
          "\n\n• Ports: 1) HDMI 2.1, (3) SuperSpeed USB 3.2 Gen 1 Type-A, (1) USB-C 3.2 Gen 2 with Display Port Alt-Mode, (1) Headphone/Mic, (1) RJ45."
          "\n\n• Wi-fi & Bluetooth: Intel Wi-Fi 6 AX201 (2x2) Wi-Fi + Bluetooth."
          "\n\n• Thermal: Alienware Inspired Cooling with the vapor chamber and Element 31 thermal interface material for efficient cooling * only on Configurations with RTX 4050 and above.",
      productImage: "assets/product/laptop/L6.png",
      productQuantity: "3636",
    ),
    ProductModel(
      //307
      productId: const Uuid().v4(),
      productTitle: "HP OMEN AMD Ryzen 7 Octa Core 7840HS - (16 GB/1 TB SSD/Windows 11 Home/6 GB Graphics/NVIDIA GeForce RTX 4050) XD0007ax Gaming Laptop  (16.1 Inch, Shadow Black, 2.32 Kg)",
      productPrice: "₹1,12,990",
      productCategory: "Laptop",
      productDescription: "• 【8-core AMD Ryzen 7 7840HS】16 threads and 16MB L3 cache allow you to dominate virtual battlefields and juggle demanding tasks with fast processing speeds and instant responsiveness."
          "\n\n• 【8 GB NVIDIA GeForce RTX 4060 Laptop GPU】Unlock an immersive gaming experience with 140W TGP that delivers AI-accelerated performance, enhanced 3D rendering, and hyper-efficient data processing."
          "\n\n• 【Upgraded memory and storage】1TB PCIe Gen4 NVMe TLC M.2 SSD provides a lag-free experience for smooth gameplay. The 16GB DDR5 RAM helps you run memory-intensive gaming applications with ease."
          "\n\n• 【Micro-edge display】The 16.1-inch, FHD, 300-nit, 165Hz, Low Blue Light, anti-glare, and micro-edge display immerses you in action with a fast 7 ms response time and 83.17% screen-to-body ratio."
          "\n\n• 【Effortless connectivity for uninterrupted gaming sessions】Wi-Fi 6E (2x2) and Bluetooth 5.3, 2 x USB Type-C, 2 x USB Type-A, and 1 x HDMI 2.1 ports equip you with fast and reliable connections."
          "\n\n• 【Long battery life】Fast charge your device to 50% in 30 mins and get back to your squad in no time with a 6-cell, 83Wh battery that lasts up to 8 hours for extended gaming sessions."
          "\n\n• 【Enhanced collaboration】Team up and tackle challenges even in dim lighting conditions with HP True Vision 1080p FHD IR camera, temporal noise reduction, 4-zone RGB backlit keyboard, and audio by B&O.",
      productImage: "assets/product/laptop/L7.png",
      productQuantity: "525",
    ),
    ProductModel(
      //308
      productId: const Uuid().v4(),
      productTitle: "MSI GF63 Thin Intel Core i5 12th Gen 12450H - (16 GB/512 GB SSD/Windows 11 Home/4 GB Graphics/NVIDIA GeForce RTX 3050/144 Hz) Thin GF63 12UC-846IN Gaming Laptop  (15.6 inch, Black, 1.86 g)",
      productPrice: "₹76,990",
      productCategory: "Laptop",
      productDescription: "• Processor: 11th Generation Intel Core i5-11260H Up To 4.40GHz."
          "\n\n• Operating System: Pre-loaded Windows 11 Home with lifetime validity |Preinstalled Software: MSI Center | In the box: Laptop, Power Adapter."
          "\n\n• Display: 40CM FHD (1920x1080), 144Hz,45%NTSC IPS-Level panel."
          "\n\n• Memory & Storage: 8GBx2 (3200MHz) DDR5 Dual Channel RAM | Storage: 512GB NVMe PCIe Gen3x4 SSD."
          "\n\n• NVIDIA GeForce GTX1650, GDDR6 4GB Graphics | Gb LAN 802.11 ax Wi-Fi 6 + Bluetooth v5.2."
          "\n\n• You can enjoy smooth gaming on the Full HD 60 Hz display, with a long-lasting battery that can last up to 7 hours.",
      productImage: "assets/product/laptop/L8.png",
      productQuantity: "2526",
    ),

    //--------------------------------------Smart Watch--------------------------------------

    ProductModel(
      //401
      productId: const Uuid().v4(),
      productTitle: "AMAZFIT GTR 2 (New version)1.39HD AMOLEDBluetooth callingupto 10 days battery life Smartwatch  (Black Strap, Free Size)",
      productPrice: "₹7,999",
      productCategory: "Watch",
      productDescription: "• [3D Curved Design & HD AMOLED Screen] The Amazfit GTR 2 smartwatch features a 1.39-inch high-definition AMOLED screen with 326ppi pixel density, covered in 3D glass, which naturally transitions to the stainless steel watch body, resulting in a better visual aesthetic and a wider content display area.;[All-round Health Tracking] The Amazfit GTR 2 smartwatch can provide 24-hour heart rate monitoring, blood-oxygen saturation measurement, sleep quality monitoring and stress level monitoring. Also included is the PAI health assessment system, which uses algorithms to convert all of complex health and activity data into one single score, to help you understand your physical state at a glance."
          "\n\n• [90 Sports Modes & 5 ATM Water-resistance] The Amazfit GTR 2 sports modes includes 90 built-in sports modes and is waterproof to a depth of up to 50 meters. Intelligent recognition of 6 sports modes also eliminates the need to manually select the sports modes, so the watch is always ready for action. 11-day Ultra-long Battery Life"
          "\n\n• [Ultra-long 14-day Battery Life] The GTR 2 sports watch is equipped with a powerful 471mAh battery that can last 14 days with typical use, and is always ready to escort you wherever your exercise takes you."
          "\n\n• [3GB Music Storage] Control mobile music playback through the watch via Bluetooth, and transfer your favorite songs to the smartwatch through your mobile phone, with a massive 3GB of local music storage. Put your wireless headphones in, your phone down, workout, and follow the rhythm of the music anytime, anywhere.; Check Out Our Store : Click on the blue Amazfit link below the Product title, to explore our other models."
          "\n\n• Color Name: Black; Included Components: Amazfit Gtr2*1, Magnetic Charger *1, Manual*1"
          "\n\n• Wristband width: 22 mm",
      productImage: "assets/product/watch/W1.png",
      productQuantity: "10",
    ),
    ProductModel(
      //402
      productId: const Uuid().v4(),
      productTitle: "AMAZFIT GTR 4 1.43AMOLED display Bluetooth calling & 6 satellite GPS positioning system Smartwatch  (Grey Strap, Free Size)",
      productPrice: "₹16,999",
      productCategory: "Watch",
      productDescription: "• Large 1.43 HD AMOLED Display: The Amazfit GTR 4 is the industry's first smartwatch with anti-glare technology on the glass bezel cover and the AMOLED display has an anti-fingerprint coating to keep your watch looking pristine. Turn your watch into your personal health and fitness dashboard and see the data that's vital to you in HD clarity."
          "\n\n• Super Strong & Accurate GPS Tracking: The Amazfit GTR 4 uses industry-leading dual-band circularly-polarized GPS antenna technology, for stronger positioning that's 99% as accurate as top handheld GPS locators. Whether you're hiking a tree-covered trail or cycling to work through a congested city center, enjoy positioning that's unimpeded by environmental and multi-path interference. You can even import a route file to the watch from the Zepp App and navigate your way along it in real-time."
          "\n\n• Smart recognition of Strength Training Exercises: The Amazfit GTR 4 can automatically recognize the movements and count the reps of dozens of strength training exercises, many of which have adjustable variations in the Zepp App, as well as track your rest time between sets. After your workout, the Zepp App will show you the muscle group you exercised and how long you exercised it for, to help keep your training efficient."
          "\n\n• Ultra-long 14-day Battery Life: Crush your professional and workout goals for up to two weeks at a time. Primed for action, the battery of the Amazfit GTR 4 packs a 475 mAh rated value, and the watch's new Battery Saver Mode even enables continued use of features like sports modes, measurement of health metrics, and more, all while saving power."
          "\n\n• Easy 24/7 Health Management: Enjoy highly-accurate 24-hour monitoring of heart rate, blood-oxygen saturation and stress levels. The watch can also detect your breathing rate, and is able to quickly measure these four important health metrics in one easy tap.",
      productImage: "assets/product/watch/W2.png",
      productQuantity: "15",
    ),
    ProductModel(
      //403
      productId: const Uuid().v4(),
      productTitle: "Apple Watch SE GPS (2nd Gen) Heart Rate Monitor, Crash Detection, Sleep Tracking  (Midnight Strap, 44mm)",
      productPrice: "₹29,999",
      productCategory: "Watch",
      productDescription: "• WHY APPLE WATCH SE — All the essentials to help you monitor your fitness, keep connected, track your health and stay safe. Now up to 20% faster, with features like Crash Detection and enhanced workout metrics, it’s a better value than ever."
          "\n\n• EASILY CUSTOMISABLE — Available in a range of sizes and colours, with dozens of straps to choose from and watch faces with complications tailored to whatever you’re into."
          "\n\n• HEALTH AND SAFETY FEATURES — Get help when you need it with Crash Detection, Fall Detection and Emergency SOS. Get deep insights into your health, including notifications if you have an irregular rhythm or an unusually high or low heart rate."
          "\n\n• SIMPLY COMPATIBLE — It works seamlessly with your Apple devices and services. Unlock your Mac automatically. Find your devices with a tap. Apple Watch requires an iPhone 8 or later with the latest iOS version."
          "\n\n• SWIMPROOF AND STYLISH — Water resistant to 50 metres. Three finishes. And a redesigned, colour-matched back case made with a new production process that reduces its carbon emissions by over 80%.",
      productImage: "assets/product/watch/W3.png",
      productQuantity: "20",
    ),
    ProductModel(
      //404
      productId: const Uuid().v4(),
      productTitle: "Apple Watch Series7 (GPS+Cellular-45mm)Graphite Stainless Steel Case-GraphiteLoop  (Grey Strap, Regular)",
      productPrice: "₹77,900",
      productCategory: "Watch",
      productDescription: "• Stay connected to family and friends with calls, texts, and email, even when you don’t have your phone"
          "\n\n• Stream music, podcasts, and audiobooks on the go, and leave your phone at home"
          "\n\n• Always-on Retina display has nearly 20% more screen area than Series 6, making everything easier to see and use"
          "\n\n• The most crack-resistant front crystal yet on an Apple Watch, IP6X dust resistance and swimproof design"
          "\n\n• Measure your blood oxygen with a powerful sensor and app"
          "\n\n• Take an ECG anytime, anywhere"
          "\n\n• Get high and low heart rate, and irregular heart rhythm notifications",
      productImage: "assets/product/watch/W4.png",
      productQuantity: "2363",
    ),
    ProductModel(
      //405
      productId: const Uuid().v4(),
      productTitle: "Fastrack Revoltt FS1+|2.01'' Biggest UltraVU Display|Industry Best 950 Nits|BT Calling Smartwatch  (Black Strap, Free Size)",
      productPrice: "₹1,799",
      productCategory: "Watch",
      productDescription: "• Biggest 2.01” UltraVU Display: Fastrack Limitless FS1+ comes with the largest 2.01” UltraVU Display with industry best 950 nits brightness and is ready to style your wrist with bright pixel"
          "\n\n• Resolution and brand new amazing colours"
          "\n\n• SingleSync BT Calling with Favourite Contacts storage (Android - 100, iOS - 50) and Quick Replies (Android)"
          "\n\n• NitroFast Charging with 10 min charge to fuel up 1 day of battery"
          "\n\n• Health Monitoring with Auto Stress monitor, 24x7 Heart Rate, Sleep Tracker, Spo2 and Women's Health"
          "\n\n•Advanced 110+ Sports Modes, 200+ Watchfaces, In-Built Games, AI Voice Assistant and many more handy features at a single tap",
      productImage: "assets/product/watch/W5.png",
      productQuantity: "3625",
    ),
    ProductModel(
      //406
      productId: const Uuid().v4(),
      productTitle: "Fire-Boltt Phoenix Smart Watch",
      productPrice: "₹54,999",
      productCategory: "Watch",
      productDescription: "• 【High Resolution Display】- Comes with a 1.3" "TFT Color Full Touch Screen and a 240*240 Pixel High Resolution this fashion smartwatch is covered to flaunt the sleek and stylish look always with 260 NITS Peak Brightness"
          "\n\n• The watch will work on a single charge for about 7 days (without Bluetooth calling) and about 4 Days with Bluetooth calling."
          "\n\n• Charging Specs - The watch needs to be charged for 3 hours to reach 100%. The charger should be a 3.7V to 5V adapter or any laptop output. For a bare minimum of 20% charge the watch needs to be charged for about 30-40 mins"
          "\n\n• You cannot store Music in the watch, you can only control the music. 【Gaming On Wrist】- Enjoy playing games on the wrist itself as you are on the go. 【Breathe Function】- Ensure your breathing exercise is fit and healthy with the breathing function."
          "\n\n• There is no volume control, however when connected to bt calling you can control the volume of the call. 【Smartphone Notifications】- Get all your mobile phone notifications on this 1.3" "Round Display Full touch smartwatch and never be late for a meeting, party or date."
          "\n\n• Supported Applications - Notifcations from all social media channels (Instagram, Whatsapp, Facebook), Call Notifications, Health Tracking (SpO2, Heart Rate, Sleep), Sports Tracking & many more (This is not a medical device)",
      productImage: "assets/product/watch/W6.png",
      productQuantity: "3636",
    ),
    ProductModel(
      //407
      productId: const Uuid().v4(),
      productTitle: "Noise Icon Buzz 1.69" "Display with Bluetooth Calling, Built-In Games, Voice Assistant Smartwatch  (Black Strap, Regular)",
      productPrice: "₹1,999",
      productCategory: "Watch",
      productDescription: "• Sharp and bright display: The 1.69’’ TFT display with 240*280px and 500 nits brightness ensures visual treat every time you look at the watch."
          "\n\n• Tru Sync: Experience fast and stable connectivity with low power consumption."
          "\n\n• BT calling: Stay in touch with your friends - right from your wrist."
          "\n\n• Utility features: Use the utility features at your disposal and become more productive - get hand wash reminders, idle alert and drink water reminder, weather forecast, set alarms and more."
          "\n\n• Noise Health Suite: Lead a better life with the battery of wellness features available in Noise Health Suite."
          "\n\n• 150+ cloud-based & customised watch faces: Style your watch the way you like to – choose from 150 cloud-based & customised watch faces."
          "\n\n• 100 sports modes with auto sports detection: Stay active and track all that you are doing with auto sports detection mode.",
      productImage: "assets/product/watch/W7.png",
      productQuantity: "525",
    ),
    ProductModel(
      //408
      productId: const Uuid().v4(),
      productTitle: "SAMSUNG Watch 4 Classic LTE 46mm Super AMOLED LTE Calling with Body Composition Tracking  (Black Strap, Free Size)",
      productPrice: "₹13,999",
      productCategory: "Watch",
      productDescription: "• Only compatible with Android Smartphones (Runs on Wear OS Powered by Samsung)"
          "\n\n• Redmi Note 12 Pro 5G features the flagship 50 MP Sony IMX766 sensor. The sensor with 1 um pixel size captures a lot more light resulting in excellent low light shots."
          "\n\n• Bioelectrical Impedance Analysis Sensor for Body Composition Analysis, Optical Heart Rate Sensor."
          "\n\n• Health Monitoring features such as Advanced Sleep Analysis & Women's Health."
          "\n\n• Enhanced Fitness tracking lets you track 90+ workouts; Enriched App availability and connectivity with Wear OS, Powered by Samsung."
          "\n\n• Item Type Name: Smart Watch; Connectivity Technology: Usb; Included Components: ‎Galaxy Watch::Watch Strap::Wireless Charger::Quick Start Quide",
      productImage: "assets/product/watch/W8.png",
      productQuantity: "2526",
    ),

    //--------------------------------------Camera--------------------------------------

    ProductModel(
      //201
      productId: const Uuid().v4(),
      productTitle: "Canon EOS 200D II DSLR Camera EF-S18-55mm IS STM  (Black)",
      productPrice: "₹55,999",
      productCategory: "Camera",
      productDescription: "• Color: Black"
          "\n\n• Cutting-edge technology"
          "\n\n• Compatible Mountings: Canon Ef-S; Photo Sensor Technology: CMOS"
          "\n\n• Compatible Mountings: Canon Ef-S; Photo Sensor Technology: CMOS, Hardware Interface: Secure Digital",
      productImage: "assets/product/camera/C1.png",
      productQuantity: "10",
    ),
    ProductModel(
      //202
      productId: const Uuid().v4(),
      productTitle: "Canon EOS 1500D DSLR Camera Body+ 18-55 mm IS II Lens  (Black)",
      productPrice: "₹39,999",
      productCategory: "Camera",
      productDescription: "• Sensor: APS-C CMOS Sensor with 24.1 MP (high resolution for large prints and image cropping). Transmission frequency (central frequency):Frequency: 2 412 to 2 462MHz. Standard diopter :-2.5 - +0.5m-1 (dpt);ISO: 100-12800 sensitivity range (critical for obtaining grain-free pictures, especially in low light)"
          "\n\n• Image Processor: DIGIC 4+ with 9 autofocus points (important for speed and accuracy of autofocus and burst photography);Video Resolution: Full HD video with fully manual control and selectable frame rates (great for precision and high-quality video work)"
          "\n\n• Connectivity: WiFi, NFC and Bluetooth built-in (useful for remotely controlling your camera and transferring pictures wirelessly as you shoot)"
          "\n\n• Lens Mount: EF-S mount compatible with all EF and EF-S lenses (crop-sensor mount versatile and compact, especially when used with EF-S lenses); Country of Origin: Taiwan"
          "\n\n• Compatible Mountings: Universal Tripod Mount; Photo Sensor Technology: CMOS",
      productImage: "assets/product/camera/C2.png",
      productQuantity: "15",
    ),
    ProductModel(
      //203
      productId: const Uuid().v4(),
      productTitle: "NIKON D 810 DSLR Camera Body with Single Lens: 24-120mm VR Lens  (Black)",
      productPrice: "₹2,09,999",
      productCategory: "Camera",
      productDescription: "• 24.5MP BSI CMOS full-frame sensor with on-sensor phase detection; 7 frame per second shooting (12 fps in 12-bit electronic shutter mode) and UHD 4K capture at up to 30p from the full width of the sensor"
          "\n\n• 51-point AF module supported by 180,000 pixel RGB metering sensor and 273 point on-sensor PDAF in live view (sensitive to -4 EV)"
          "\n\n• 3.2 2.36M-dot touchscreen and Shutter range of 900 - 1/8000 sec"
          "\n\n• Dual UHS-II SD card slots and Snapbridge Bluetooth and Wi-Fi system (with Raw and video transfer)"
          "\n\n• Hardware Interface: Secure Digital; Compatible Mountings: Nikon F",
      productImage: "assets/product/camera/C3.png",
      productQuantity: "20",
    ),
    ProductModel(
      //204
      productId: const Uuid().v4(),
      productTitle: "NIKON D850 DSLR Camera 24-120 mm VR Lens",
      productPrice: "₹2,39,900",
      productCategory: "Camera",
      productDescription: "• "
          "\n\n• D850 with the AF-S NIKKOR 24-120MM F/4G ED VR(64GB SD included)"
          "\n\n• Comes with battery, charger and manual"
          "\n\n• Create epic film masterpieces in full-frame 4K UHD with NIKKOR wide-angle lenses or prolong exquisite moments with its 120p/100p Full HD slow-motion recording"
          "\n\n• Fashion, nature, sports or wedding photography and videography; Country of Origin: Japan"
          "\n\n• Hardware Interface: Bluetooth; Wireless Communication Technology: Bluetooth Specification Version 4.1 Operating Frequency: Bluetooth: 2402 To 2480 Mhz Bluetooth Low Energy: 2402 To 2480 Mhz",
      productImage: "assets/product/camera/C4.png",
      productQuantity: "2363",
    ),
    ProductModel(
      //205
      productId: const Uuid().v4(),
      productTitle: "Fastrack Revoltt FS1+|2.01'' Biggest UltraVU Display|Industry Best 950 Nits|BT Calling Smartwatch  (Black Strap, Free Size)",
      productPrice: "₹1,799",
      productCategory: "Camera",
      productDescription: "• NIKON D7500 DSLR Camera Body with 18-140 mm Lens  (Black)"
          "\n\n• 20.9MP DX-Format CMOS Sensor, SnapBridge Bluetooth and Wi-Fi;4K UHD Video Recording at 30 fps"
          "\n\n• Multi-CAM 3500FX II 51-Point AF System"
          "\n\n• Native ISO 51200, Expanded ISO 1,640,000"
          "\n\n• Compatible Mountings: Nikon F; Hardware Interface: Audio Video Port"
          "\n\n• 180k-Pixel RGB Sensor and Group Area AF; Country of Origin: Japan",
      productImage: "assets/product/camera/C5.png",
      productQuantity: "3625",
    ),
    ProductModel(
      //206
      productId: const Uuid().v4(),
      productTitle: "SONY Alpha ILCE-7M4K Full Frame Mirrorless Camera with 28-70 mm Zoom LensFeaturing Eye AF and 4K movie recording  (Black)",
      productPrice: "₹2,30,900",
      productCategory: "Camera",
      productDescription: "• Quickly set the visual mood with ten Creative Look presets, Reliable autofocus, impressive speed, Fast Hybrid AF, evolved, continuous shooting with fast buffer release, Improved Real-time Eye AF"
          "\n\n• 7K oversampling for beautifully expressive, richly detailed images (When recording 4K movies at up to 30p, full-frame 7K oversampling is possible, resulting in high-resolution, highly detailed 4K."
          "\n\n• 33MP Full-Frame Exmor R CMOS Sensor"
          "\n\n• 4K 60p Video"
          "\n\n• Up to 10 fps Shooting, ISO 100-51201"
          "\n\n• 759 AF Points (Wide AF Coverage)"
          "\n\n• 10-Bit 4:2:2 , S-Cinetone",
      productImage: "assets/product/camera/C6.png",
      productQuantity: "3636",
    ),
    ProductModel(
      //207
      productId: const Uuid().v4(),
      productTitle: "SONY Alpha ILCE-6400L APS-C Mirrorless Camera with 16-50 mm Power Zoom Lens Featuring Eye AF and 4K movie recording  (Black)",
      productPrice: "₹79,999",
      productCategory: "Camera",
      productDescription: "• 4K movies and pro-level features, Natural-looking images that match what you see, Cleaner images even in dim light."
          "\n\n• Creative movie production, High-resolution 4K recording, Create time-lapse movies, Vlog with useful features, Take advantage of various movie functions, A high resolution LCD monitor with handy touchscreen functions."
          "\n\n• Real time eye AF and real time tracking;World fastest 0.02 Sec AF speed with 425 phase detection and contrast points ; Operating Temperature: 32 - 104 degrees F / 0 - 40 degrees C ; Performance Features: Fast hybrid autofocus allows for rapid, accurate subject tracking for great photographic experience ; Connectivity: Wi-Fi/NFC/HDMI/USB/Bluetooth"
          "\n\n• 24.2MP, EXMOR CMOS sensor with outstanding light sensitivity;11 FPS continuous shooting with AF/AE"
          "\n\n• 180 degree titltable touch LCD screen;ISO sensitivity up to 102400; High resolution, sensitivity and color reproduction capability;Smooth and stable AF"
          "\n\n• Durability for up to 200,000 shutter cycles;HLG(hybrid log Gamma ) support for instant HDR workflow"
          "\n\n• Compatible Mountings: Sony E",
      productImage: "assets/product/camera/C7.png",
      productQuantity: "525",
    ),
    ProductModel(
      //208
      productId: const Uuid().v4(),
      productTitle: "SONY ZV-E10L Mirrorless Camera Body with 1650 mm Power Zoom Lens Vlog Camera  (Black)",
      productPrice: "₹61,499",
      productCategory: "Camera",
      productDescription: "• 4K video with oversampling for greater detail, Easy, impressive vlogs, One-touch control of background blurring, Interchangeable-lens camera for vlogging."
          "\n\n• Easy background blur control, Natural-looking skin tones, Smooth and stable images even while walking, Easy sped-up and slowed-down motion, Clear recording even outdoors, For even higher audio quality."
          "\n\n• Add special effects in-camera, Edit movies from your smartphone, Create time-lapse movies, Wi-Fi & Bluetooth"
          "\n\n• Interchangeable-lens camera for vlogging"
          "\n\n• Large APS-C type 24.2-megapixel28 Exmor CMOS sensor"
          "\n\n• Directional 3-Capsule Mic supplied with wind screen"
          "\n\n• Compatible Mountings: Sony E",
      productImage: "assets/product/camera/C8.png",
      productQuantity: "2526",
    ),
  ];
}
